comment = document.getElementsByClassName("comment")

$(function(){

    $("#StevenTheModel").on("click", function(){
        $.getJSON('/model', function(data) {

            console.log("hello")

            comment.forEach(function() {

                console.log("this works")

                // if (message == 1) {
                //     comment.addClass("bully")
                // }
                // else {
                //     comment.addClass("positive")
                // }
            })



        })
    })
})